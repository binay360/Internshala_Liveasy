package com.rest.spring.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.rest.spring.dao.LiveEasyDao;
import com.rest.spring.entities.*;

import com.rest.spring.entities.Load;

@Service
public class LoadSericeImplement implements LoadService {
	
	List<Load> list;
	
	@Autowired
    private LiveEasyDao dao_;
	
	public LoadSericeImplement() {
		list = new ArrayList<>();
		list.add(new Load("Delhi","Patna","Plastic","Big Truck","3","3 ton","Delivered","123","09-05-2022"));
		list.add(new Load("Delhi","Patna","Plastic","Big Truck","3","3 ton","Delivered","123","09-05-2022"));
	}

	@Override
	public List<Load> getLoad(){
		return dao_.findAll();
	}

	@SuppressWarnings("deprecation")
	@Override
	public Load getLoadById(String Id) {
//		Load load_by_shipperID =null;
//		for(Load load :list) {
//			if(Integer.parseInt(load.getShipperId())==(Id)) {
//				load_by_shipperID =load;
//				break;
//			}
//		}
		return dao_.getOne(Id);
		
	}

	@Override
	public Load addLoad(Load load) {
//		list.add(load);
		dao_.save(load);
		return load;
	}

	@Override
	public Load updateLoad(Load load) {
//		list.forEach(e ->{
//			if(e.getShipperId().equals(load.getShipperId())) {
//				e.setWeight(load.getWeight());
//				e.setDate(load.getDate());
//				e.setLoadingPoint(load.getLoadingPoint());
//				e.setNoOfTrucks(load.getNoOfTrucks());
//				e.setProductType(load.getProductType());
//				e.setTruckType(load.getTruckType());
//				e.setUnloadingPoint(load.getUnloadingPoint());
//				e.setWeight(load.getWeight());
//			}
//		});
		dao_.save(load);
		return load;
	}

	@SuppressWarnings("deprecation")
	@Override
	public void deleteLoad(String id) {
//		list=this.list.stream().filter(e->!(e.getShipperId().equals(id))).collect(Collectors.toList());
		Load load = dao_.getOne(id);
		dao_.delete(load);
	}

}
