package com.rest.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
public class InternshalaSpringBootPostgresqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(InternshalaSpringBootPostgresqlApplication.class, args);
	}

}
