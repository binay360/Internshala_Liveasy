package com.rest.spring.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="liveasy")
public class Liveasy {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String shipperId;
	@Column(name="loadingPoint")
	private String loadingPoint;
	
	@Column(name="unloadingPoint")
	private String unLoadingPoint;
	
	@Column(name="productType")
	private String productType;
	
	@Column(name="truckType")
	private String truckType;
	
	@Column(name="noOfTrucks")
	private String noOfTrucks;
	
	@Column(name="weight")
	private String weight;
	
	@Column(name="comment")
	private String comment;
	
	@Column(name="date")
	private String date;
	
	
	public Liveasy() {
		super();
	}
	//constructor with comment
	public Liveasy(String loadingPoint, String unLoadingPoint, String productType, String truckType, String noOfTrucks,
			String weight, String comment, String shipperId, String date) {
		super();
		this.loadingPoint = loadingPoint;
		this.unLoadingPoint = unLoadingPoint;
		this.productType = productType;
		this.truckType = truckType;
		this.noOfTrucks = noOfTrucks;
		this.weight = weight;
		this.comment = comment;
		this.shipperId = shipperId;
		this.date = date;
	}	
	
	//constructor without comment
	public Liveasy(String loadingPoint, String unLoadingPoint, String productType, String truckType, String noOfTrucks,
			String weight, String shipperId, String date) {
		super();
		this.loadingPoint = loadingPoint;
		this.unLoadingPoint = unLoadingPoint;
		this.productType = productType;
		this.truckType = truckType;
		this.noOfTrucks = noOfTrucks;
		this.weight = weight;
		this.shipperId = shipperId;
		this.date = date;
	}
	public String getLoadingPoint() {
		return loadingPoint;
	}
	public void setLoadingPoint(String loadingPoint) {
		this.loadingPoint = loadingPoint;
	}
	public String getUnLoadingPoint() {
		return unLoadingPoint;
	}
	public void setUnLoadingPoint(String unLoadingPoint) {
		this.unLoadingPoint = unLoadingPoint;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productPType) {
		this.productType = productPType;
	}
	public String getTruckType() {
		return truckType;
	}
	public void setTruckType(String truckType) {
		this.truckType = truckType;
	}
	public String getNoOfTrucks() {
		return noOfTrucks;
	}
	public void setNoOfTrucks(String noOfTrucks) {
		this.noOfTrucks = noOfTrucks;
	}
	public String getWeight() {
		return weight;
	}
	public void setWeight(String weight) {
		this.weight = weight;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public String getShipperId() {
		return shipperId;
	}
	public void setShipperId(String shipperId) {
		this.shipperId = shipperId;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}

}
