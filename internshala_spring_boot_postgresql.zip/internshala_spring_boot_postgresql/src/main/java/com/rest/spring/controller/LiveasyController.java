package com.rest.spring.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.rest.springexception.ResourceNotFoundException;
import com.rest.spring.Service.LoadService;
//import com.rest.springrepository.LiveasyRepo;
import com.rest.spring.entities.Load;
//import com.rest.spring.model.Liveasy;
@RestController
public class LiveasyController {
	@Autowired
	private  LoadService loadServ;
	//get method
	@GetMapping("/load")
	public List<Load> getLoad(){
		return this.loadServ.getLoad();
	}
	@GetMapping("/load/{shipperID}")
	public Load getLoadById(@PathVariable String shipperID){
		return this.loadServ.getLoadById(shipperID);
	}
	@PostMapping("/load")
	public Load addLoad(@RequestBody Load load) {
		return this.loadServ.addLoad(load);
		
	}
	@PutMapping("/load")
	public Load updateLoad(@RequestBody Load load) {
		return this.loadServ.updateLoad(load);
	}
	@DeleteMapping("/load/{shipperID}")
	public ResponseEntity<HttpStatus> deleteLoad(@PathVariable String id){
		try {
			this.loadServ.deleteLoad(id);
			return new ResponseEntity<>(HttpStatus.OK);
		}
		catch(Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
}
