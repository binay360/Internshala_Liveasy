package com.rest.spring.Service;

import java.util.List;

//import org.springframework.web.bind.annotation.RequestBody;

import com.rest.spring.entities.Load;

public interface LoadService {
	public List<Load> getLoad();
	public Load getLoadById(String ID);
	public Load addLoad(Load load);
	public Load updateLoad(Load load);
	public void deleteLoad(String id);

}
