package com.rest.spring.dao;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.stereotype.Repository;

import com.rest.spring.entities.Load;

//@SpringBootApplication(scanBasePackages={"com.rest.springrepository.LiveasyRepo", "com.rest.springrepository.LiveasyRepo"})
@EnableJpaRepositories("com.rest.spring.dao")
@Repository
public interface LiveEasyDao extends JpaRepository<Load, String>{
	
}
